Pelican theme - SoMA
====================


Features
--------
* Simple and clean interface.
* Looks and works well on all the mobile devices.


Screenshot
----------

  ![Screenshot](screenshot.png)


Live example
------------

Go to [LaunchYard's blog][lyblog] to see how this theme looks like live!



  [lyblog]: http://blog.launchyard.com
