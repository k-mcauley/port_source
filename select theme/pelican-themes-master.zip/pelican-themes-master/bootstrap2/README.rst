Bootstrap 2 theme
==================

This is (yet another) theme for Pelican inspired by `Twitter Bootstrap 2.0 <http://twitter.github.com/bootstrap/>`_.

It supports `Font-Awesome <http://fortawesome.github.com/Font-Awesome/>`_ icons,
tag clouds, translations, and other features from Pelican's default ``notmyidea`` theme.

You can see this theme live via `my Github Page <http://farseerfc.github.com/>`_,
which will be kept up-to-date with the latest version of this theme.

Feel free to use it.

Screenshot
----------

.. image:: screenshot.png
   :alt: Screenshot of the theme
