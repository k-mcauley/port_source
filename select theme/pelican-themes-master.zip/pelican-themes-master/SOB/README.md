Son of a Bitch Theme
=====================
By: Goat Avenger

I needed a custom theme; thusly, I hacked zurb-F5-basic.

If I'm correct I made a simple theme even simpler.  That's about it.  Some of the more advanced functionality may or may not work.

This includes - google analytics
-It's commented out 'cause fuck google.
              - Disqus
-what's that?  I don't know, I don't use it...
Also added a disclaimer template.  Got to have one of those...

preview the theme at http://blog.goatavenger.com 

YOU GET NOTHING!  YOU LOSE!

