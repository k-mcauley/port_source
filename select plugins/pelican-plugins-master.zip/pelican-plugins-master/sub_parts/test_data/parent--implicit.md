title: Implicit sub-article
tags: atag

Sub-article based on filename as implicit slug.
