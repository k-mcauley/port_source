css-html-js-minify wrapper for Pelican
======================================

This plugin simply finds all css, html and javascript files in the pelican
output folder and minifies them in place using `css-html-js-minify`_.

`css-html-js-minify`_ needs to be installed separately and importable.

.. _`css-html-js-minify`: https://github.com/juancarlospaco/css-html-js-minify
