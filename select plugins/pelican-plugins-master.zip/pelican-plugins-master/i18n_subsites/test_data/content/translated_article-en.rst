A translated article
====================
:slug: translated-article
:lang: en
:date: 2014-09-13

A simple article with a translation.
Here is a link to `some image <{filename}/images/img.png>`_.
