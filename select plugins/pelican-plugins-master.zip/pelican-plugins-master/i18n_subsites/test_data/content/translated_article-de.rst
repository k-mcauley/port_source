Ein übersetzter Artikel
=======================
:slug: translated-article
:lang: de
:date: 2014-09-14

Ein einfacher Artikel mit einer Übersetzung.
Hier ist ein Link zur `einigem Bild <{filename}/images/img.png>`_.
