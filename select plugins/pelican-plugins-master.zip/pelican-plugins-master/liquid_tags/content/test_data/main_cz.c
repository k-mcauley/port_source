#include <stdio.h>

int main(int argc, char** argv){
    printf("Dobr�");

    return 0;
}
