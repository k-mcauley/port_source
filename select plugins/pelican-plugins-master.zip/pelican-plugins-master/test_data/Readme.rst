Test Data
---------

Place tests for your plugin here. ``test_data`` folder contains following
common data for your tests, if you need them. 

===============   ===========================
File/Folder       Description
===============   ===========================
content           A sample content folder
themes            Default themes from Pelican
pelican.conf.py   A sample settings file
===============   ===========================
