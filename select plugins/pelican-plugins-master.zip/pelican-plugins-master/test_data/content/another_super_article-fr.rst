Trop bien !
###########

:lang: fr
:slug: oh-yeah

Et voila du contenu en français
