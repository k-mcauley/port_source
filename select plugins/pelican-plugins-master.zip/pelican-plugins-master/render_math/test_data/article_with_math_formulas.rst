Math formulas
#############

:date: 2019-09-10
:yeah: oh yeah !
:summary: :math:`A_\text{c} = (\pi/4) d^2`

The area of a circle is :math:`A_\text{c} = (\pi/4) d^2`.

.. math::

  α_t(i) = P(O_1, O_2, … O_t, q_t = S_i λ)

    A =
    \begin{bmatrix}
    a_{11} & a_{12} & a_{13} \
    a_{21} & a_{22} & a_{23} \
    a_{31} & a_{32} & a_{33}
    \end{bmatrix}
    