# unity webgl options

DEFAULT_WIDTH = 960
DEFAULT_HEIGHT = 600
DEFAULT_ALIGN = 'center'

# paths

GAMES_ROOT_DIR = '/games'  # directory with games
TEMPLATE_PATH = '/games/utemplate'  # template path
